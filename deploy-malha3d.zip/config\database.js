const { Sequelize } = require('sequelize');

// Configurações do banco de dados para o Supabase (PostgreSQL)
const useUrl = process.env.SUPABASE_DB_URL ? true : false;
const commonOptions = {
  dialect: 'postgres',
  dialectOptions: {
    ssl: {
      require: true,
      rejectUnauthorized: false // Importante para conexões com Supabase via SSL
    }
  },
  logging: process.env.NODE_ENV === 'development' ? console.log : false,
  define: {
    timestamps: true,
    underscored: true,
    freezeTableName: true
  }
};

const dbConfig = {
  development: useUrl ? { use_env_variable: 'SUPABASE_DB_URL', ...commonOptions } : { ...commonOptions },
  test: useUrl ? { use_env_variable: 'SUPABASE_DB_URL', ...commonOptions } : { ...commonOptions },
  staging: useUrl ? { use_env_variable: 'SUPABASE_DB_URL', ...commonOptions } : { ...commonOptions },
  production: useUrl ? {
    use_env_variable: 'SUPABASE_DB_URL',
    ...commonOptions,
    define: { ...commonOptions.define, paranoid: true }
  } : { ...commonOptions }
};

// Cria conexão com o banco de dados
let sequelize;
if (process.env.NODE_ENV === 'test') {
  sequelize = new Sequelize('sqlite::memory:', {
    logging: false,
    define: {
      timestamps: true,
      underscored: true,
      freezeTableName: true
    }
  });
  if (process.env.SUPABASE_DB_URL && process.env.SUPABASE_DB_URL.includes('supabase.com')) {
    // Usando parâmetros explícitos para burlar o bug de parsing de URL da Hostinger com caracteres especiais
    sequelize = new Sequelize('postgres', 'postgres.jndjarkqjhsayiuneakk', 'LrZan0235!@#!@#!@#', {
      host: 'aws-0-us-west-2.pooler.supabase.com',
      port: 6543,
      ...commonOptions
    });
  } else {
    sequelize = new Sequelize(process.env.SUPABASE_DB_URL, commonOptions);
  }

// Função para testar conexão
const testConnection = async () => {
  try {
    await sequelize.authenticate();
    console.log('Conexão com o banco de dados estabelecida com sucesso.');
    return true;
  } catch (error) {
    console.error('Não foi possível conectar ao banco de dados:', error);
    return false;
  }
};

// Função para sincronizar banco de dados
const syncDatabase = async (force = false) => {
  try {
    await sequelize.sync({ force });
    console.log('Banco de dados sincronizado com sucesso.');
    return true;
  } catch (error) {
    console.error('Erro ao sincronizar banco de dados:', error);
    return false;
  }
};

// Função removida: SQLite não precisa criar database, PostgreSQL em nuvem já vem criado.
const createDatabaseIfNotExists = async () => {
  console.log('Utilizando Supabase: O banco de dados Postgres já existe na nuvem.');
  return true;
};

// Event listeners do Sequelize
sequelize.authenticate()
  .then(() => {
    console.log('Conexão com o banco de dados estabelecida com sucesso.');
  })
  .catch(err => {
    console.error('Não foi possível conectar ao banco de dados:', err);
  });

module.exports = {
  sequelize,
  Sequelize,
  dbConfig,
  testConnection,
  syncDatabase,
  createDatabaseIfNotExists
};
